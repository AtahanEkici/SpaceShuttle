﻿# Play Services

A collection of tools for managing and using command line apps packaged with the Android SDK.
Forked from a subset of [unity-jar-resolver](https://github.com/googlesamples/unity-jar-resolver).
